import { ArrowLeft, ShoppingCart } from "lucide-react";
import { Link, useParams } from "react-router-dom";
import Badge from "../components/Badge.jsx";
import { formatNaira } from "../data/marketData.js";

export default function ProductDetailsPage({ products, onBuy }) {
  const { id } = useParams();
  const product = products.find((item) => item.id === id);

  if (!product) {
    return (
      <div className="p-3">
        <Link to="/" className="inline-flex items-center gap-2 text-sm font-semibold text-gray-700">
          <ArrowLeft size={17} />
          Back home
        </Link>
        <div className="mt-3 bg-white p-4 text-sm text-gray-600">Product not found.</div>
      </div>
    );
  }

  return (
    <div>
      <div className="px-3 py-2 text-sm text-gray-600">
        <Link to="/" className="text-gray-600">
          Home
        </Link>{" "}
        / {product.platform} / Details
      </div>
      <div className="bg-market-dark px-3 py-2 text-sm font-bold text-white">
        {product.platform} Package Details
      </div>
      <section className="border-x border-b border-market-line bg-white p-3">
        <div className="flex gap-3">
          <div
            className={`flex h-14 w-14 shrink-0 items-center justify-center rounded text-base font-black text-white ${product.color}`}
          >
            {product.icon}
          </div>
          <div className="min-w-0 flex-1">
            <h1 className="text-base font-extrabold leading-snug text-gray-900">{product.title}</h1>
            <p className="mt-1 text-sm leading-5 text-gray-600">{product.details}</p>
          </div>
        </div>
        <div className="mt-4 grid grid-cols-2 gap-2 rounded border border-gray-200 bg-gray-50 p-3">
          <div>
            <p className="text-[11px] font-semibold uppercase text-gray-500">Stock</p>
            <p className="text-sm font-bold text-gray-900">{product.stock}</p>
          </div>
          <div className="text-right">
            <p className="text-[11px] font-semibold uppercase text-gray-500">Price per pc</p>
            <p className="text-sm font-extrabold text-gray-900">from {formatNaira(product.price)}</p>
          </div>
        </div>
        <div className="mt-3 flex flex-wrap gap-1.5">
          <Badge variant="shield">{product.speed}</Badge>
          <Badge variant="star">{product.rating}</Badge>
          <Badge variant="thumb">{product.support}</Badge>
          <Badge variant="cart">{product.orders}</Badge>
        </div>
        <button
          type="button"
          onClick={() => onBuy(product)}
          className="tap-highlight mt-4 flex h-12 w-full items-center justify-center gap-2 rounded bg-market-green text-base font-bold text-white shadow-soft"
        >
          <ShoppingCart size={19} />
          Buy
        </button>
      </section>
    </div>
  );
}
