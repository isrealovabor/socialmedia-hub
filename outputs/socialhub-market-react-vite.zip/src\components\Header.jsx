import { ChevronDown, Menu, Search, UserCircle } from "lucide-react";
import { Link, useNavigate } from "react-router-dom";
import CategoryDropdown from "./CategoryDropdown.jsx";

export default function Header({ categoryOpen, onCategoryToggle, onCategoryClose }) {
  const navigate = useNavigate();

  return (
    <header className="sticky top-0 z-30 bg-white shadow-soft">
      <div className="flex h-14 items-center justify-between border-b border-market-line px-3">
        <Link to="/" className="tap-highlight flex items-center gap-2" onClick={onCategoryClose}>
          <span className="flex h-9 w-14 items-center justify-center rounded-sm bg-market-red text-base font-black tracking-wide text-white">
            SHM
          </span>
          <span className="text-lg font-semibold text-gray-800">market.com</span>
        </Link>
        <div className="flex items-center gap-1">
          <button
            type="button"
            aria-label="Search"
            className="tap-highlight flex h-10 w-10 items-center justify-center rounded text-gray-700"
          >
            <Search size={22} />
          </button>
          <button
            type="button"
            aria-label="Account"
            onClick={() => navigate("/dashboard")}
            className="tap-highlight flex h-10 w-10 items-center justify-center rounded text-gray-700"
          >
            <UserCircle size={24} />
          </button>
        </div>
      </div>
      <div className="bg-white px-3 py-2">
        <button
          type="button"
          onClick={onCategoryToggle}
          className="tap-highlight flex h-11 w-full items-center rounded bg-market-green px-3 text-left text-sm font-bold text-white shadow-soft"
        >
          <Menu size={21} className="mr-3 shrink-0" />
          <span className="min-w-0 flex-1">Select a category</span>
          <ChevronDown
            size={20}
            className={`shrink-0 transition-transform ${categoryOpen ? "rotate-180" : ""}`}
          />
        </button>
      </div>
      <CategoryDropdown open={categoryOpen} onSelect={onCategoryClose} />
    </header>
  );
}
