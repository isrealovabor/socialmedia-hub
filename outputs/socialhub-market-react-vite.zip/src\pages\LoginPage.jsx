import { Link } from "react-router-dom";

export default function LoginPage() {
  return (
    <div>
      <div className="bg-market-dark px-3 py-2 text-sm font-bold text-white">Login</div>
      <form className="space-y-3 border-x border-b border-market-line bg-white p-3">
        <label className="block">
          <span className="text-xs font-bold text-gray-600">Email</span>
          <input
            type="email"
            className="mt-1 h-11 w-full rounded border border-gray-300 px-3 outline-none focus:border-market-green"
            placeholder="you@example.com"
          />
        </label>
        <label className="block">
          <span className="text-xs font-bold text-gray-600">Access code</span>
          <input
            type="text"
            className="mt-1 h-11 w-full rounded border border-gray-300 px-3 outline-none focus:border-market-green"
            placeholder="Enter access code"
          />
        </label>
        <Link
          to="/dashboard"
          className="tap-highlight flex h-11 w-full items-center justify-center rounded bg-market-green text-sm font-bold text-white"
        >
          Login
        </Link>
        <p className="text-center text-sm text-gray-600">
          New here?{" "}
          <Link to="/register" className="font-bold text-market-green">
            Create an account
          </Link>
        </p>
      </form>
    </div>
  );
}
