import { ShieldCheck, ShoppingCart, Star, ThumbsUp } from "lucide-react";

const variants = {
  shield: {
    className: "bg-green-100 text-green-800 border-green-200",
    Icon: ShieldCheck,
  },
  star: {
    className: "bg-yellow-100 text-yellow-800 border-yellow-200",
    Icon: Star,
  },
  thumb: {
    className: "bg-green-100 text-green-800 border-green-200",
    Icon: ThumbsUp,
  },
  cart: {
    className: "bg-gray-100 text-gray-700 border-gray-200",
    Icon: ShoppingCart,
  },
};

export default function Badge({ variant, children }) {
  const badge = variants[variant] ?? variants.cart;
  const Icon = badge.Icon;

  return (
    <span
      className={`inline-flex h-7 min-w-0 items-center gap-1 rounded border px-2 text-xs font-semibold ${badge.className}`}
    >
      <Icon size={13} strokeWidth={2.4} />
      {children}
    </span>
  );
}
