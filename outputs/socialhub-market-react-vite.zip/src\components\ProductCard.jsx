import { ShoppingCart } from "lucide-react";
import { Link } from "react-router-dom";
import Badge from "./Badge.jsx";
import { formatNaira } from "../data/marketData.js";

export default function ProductCard({ product, onBuy }) {
  return (
    <article className="border-b border-market-line bg-white px-3 py-3">
      <div className="grid grid-cols-[3rem_1fr_6.4rem] gap-3">
        <div
          className={`flex h-12 w-12 items-center justify-center rounded text-sm font-black text-white shadow-soft ${product.color}`}
        >
          {product.icon}
        </div>
        <div className="min-w-0">
          <p className="pr-1 text-sm font-semibold leading-snug text-gray-800">
            {product.title} | {product.description}
          </p>
        </div>
        <div className="flex flex-col items-end">
          <p className="text-right text-xs font-bold text-gray-800">{product.stock}</p>
          <p className="mt-1 text-right text-[11px] text-gray-500">Price per pc</p>
          <p className="text-right text-sm font-extrabold text-gray-900">
            from {formatNaira(product.price)}
          </p>
          <button
            type="button"
            onClick={() => onBuy(product)}
            className="tap-highlight mt-2 flex h-10 w-24 items-center justify-center gap-1 rounded bg-market-green text-sm font-bold text-white shadow-soft"
          >
            <ShoppingCart size={17} />
            Buy
          </button>
        </div>
      </div>
      <div className="mt-3 flex items-end justify-between gap-2">
        <div className="flex flex-wrap gap-1.5">
          <Badge variant="shield">{product.speed}</Badge>
          <Badge variant="star">{product.rating}</Badge>
          <Badge variant="thumb">{product.support}</Badge>
          <Badge variant="cart">{product.orders}</Badge>
        </div>
        <Link
          to={`/product/${product.id}`}
          className="shrink-0 text-sm font-semibold text-blue-700 underline underline-offset-2"
        >
          More...
        </Link>
      </div>
    </article>
  );
}
