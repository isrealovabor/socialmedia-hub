import { useState } from "react";
import { formatNaira, depositHistory } from "../data/marketData.js";

export default function WalletPage({ balance, onDeposit }) {
  const [amount, setAmount] = useState("");
  const [method, setMethod] = useState("Bank Transfer");
  const [notice, setNotice] = useState("");

  const submitDeposit = (event) => {
    event.preventDefault();
    const numericAmount = Number(amount);
    if (!numericAmount || numericAmount < 1000) {
      setNotice("Enter an amount of at least NGN 1,000.");
      return;
    }
    onDeposit(numericAmount);
    setNotice(`Mock ${method} deposit added.`);
    setAmount("");
  };

  return (
    <div>
      <div className="bg-market-dark px-3 py-2 text-sm font-bold text-white">Wallet</div>
      <section className="border-x border-b border-market-line bg-white p-3">
        <p className="text-xs font-bold uppercase text-gray-500">Available balance</p>
        <p className="mt-1 text-3xl font-black text-gray-900">{formatNaira(balance)}</p>
      </section>
      <section className="mt-3">
        <div className="bg-market-dark px-3 py-2 text-sm font-bold text-white">Deposit Funds</div>
        <form onSubmit={submitDeposit} className="space-y-3 border-x border-b border-market-line bg-white p-3">
          <label className="block">
            <span className="text-xs font-bold text-gray-600">Amount in naira</span>
            <input
              type="number"
              min="1000"
              value={amount}
              onChange={(event) => setAmount(event.target.value)}
              className="mt-1 h-11 w-full rounded border border-gray-300 px-3 outline-none focus:border-market-green"
              placeholder="10000"
            />
          </label>
          <label className="block">
            <span className="text-xs font-bold text-gray-600">Deposit method</span>
            <select
              value={method}
              onChange={(event) => setMethod(event.target.value)}
              className="mt-1 h-11 w-full rounded border border-gray-300 bg-white px-3 outline-none focus:border-market-green"
            >
              <option>Bank Transfer</option>
              <option>Bitcoin</option>
            </select>
          </label>
          <button
            type="submit"
            className="tap-highlight h-11 w-full rounded bg-market-green text-sm font-bold text-white"
          >
            Submit
          </button>
          {notice && <p className="text-sm font-semibold text-market-green">{notice}</p>}
        </form>
      </section>
      <section className="mt-3">
        <div className="bg-market-dark px-3 py-2 text-sm font-bold text-white">Deposit History</div>
        <div className="border-x border-market-line bg-white">
          {depositHistory.map((deposit) => (
            <div key={deposit.id} className="flex items-center justify-between border-b border-market-line px-3 py-3">
              <div>
                <p className="text-sm font-bold text-gray-900">{deposit.method}</p>
                <p className="text-xs text-gray-500">{deposit.id}</p>
              </div>
              <div className="text-right">
                <p className="text-sm font-bold text-gray-900">{formatNaira(deposit.amount)}</p>
                <p className="text-xs font-semibold text-market-green">{deposit.status}</p>
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}
