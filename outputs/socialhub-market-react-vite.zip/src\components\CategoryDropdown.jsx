import { ChevronRight } from "lucide-react";
import { Link } from "react-router-dom";
import { categories } from "../data/marketData.js";

export default function CategoryDropdown({ open, onSelect }) {
  if (!open) return null;

  return (
    <div className="border-x border-b border-market-line bg-gray-100 shadow-soft">
      {categories.map((category) => (
        <Link
          key={category.slug}
          to={`/category/${category.slug}`}
          onClick={onSelect}
          className="tap-highlight flex min-h-11 items-center gap-3 border-b border-gray-200 px-3 text-sm font-medium text-gray-700 last:border-b-0"
        >
          <span className="h-5 w-5 shrink-0 rounded-sm bg-gray-300" />
          <span className="min-w-0 flex-1">{category.name}</span>
          <ChevronRight size={17} className="shrink-0 text-gray-500" />
        </Link>
      ))}
    </div>
  );
}
