export default {
  content: ["./index.html", "./src/**/*.{js,jsx}"],
  theme: {
    extend: {
      colors: {
        market: {
          green: "#21a453",
          dark: "#3a3f43",
          page: "#f1f3f4",
          line: "#d9dee2",
          yellow: "#ffe168",
          red: "#e22c2c",
        },
      },
      boxShadow: {
        soft: "0 1px 2px rgba(15, 23, 42, 0.08)",
      },
    },
  },
  plugins: [],
};
