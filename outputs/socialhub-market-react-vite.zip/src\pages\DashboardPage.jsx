import { Link } from "react-router-dom";
import { LogOut, PackageCheck, ShoppingCart, WalletCards } from "lucide-react";
import { formatNaira, recentOrders } from "../data/marketData.js";

export default function DashboardPage({ walletBalance, cartCount }) {
  return (
    <div>
      <div className="bg-market-dark px-3 py-2 text-sm font-bold text-white">Dashboard</div>
      <section className="border-x border-b border-market-line bg-white p-3">
        <p className="text-xs font-bold uppercase text-gray-500">Wallet balance</p>
        <p className="mt-1 text-3xl font-black text-gray-900">{formatNaira(walletBalance)}</p>
        <div className="mt-4 grid grid-cols-2 gap-2">
          <QuickButton to="/wallet" icon={WalletCards} label="Deposit" />
          <QuickButton to="/dashboard" icon={PackageCheck} label="Orders" />
          <QuickButton to="/cart" icon={ShoppingCart} label={`Cart ${cartCount ? cartCount : ""}`} />
          <QuickButton to="/login" icon={LogOut} label="Logout" />
        </div>
      </section>
      <section className="mt-3">
        <div className="bg-market-dark px-3 py-2 text-sm font-bold text-white">Recent Orders</div>
        <div className="border-x border-market-line bg-white">
          {recentOrders.map((order) => (
            <div key={order.id} className="border-b border-market-line px-3 py-3">
              <div className="flex items-start justify-between gap-3">
                <div className="min-w-0">
                  <p className="text-sm font-bold text-gray-900">{order.item}</p>
                  <p className="text-xs text-gray-500">{order.id}</p>
                </div>
                <span className="rounded bg-gray-100 px-2 py-1 text-xs font-bold text-gray-700">
                  {order.status}
                </span>
              </div>
              <p className="mt-1 text-sm font-semibold text-gray-700">{formatNaira(order.total)}</p>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}

function QuickButton({ to, icon: Icon, label }) {
  return (
    <Link
      to={to}
      className="tap-highlight flex h-12 items-center justify-center gap-2 rounded border border-gray-200 bg-gray-50 text-sm font-bold text-gray-800"
    >
      <Icon size={18} className="text-market-green" />
      {label}
    </Link>
  );
}
