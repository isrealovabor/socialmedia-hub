import { useMemo, useState } from "react";
import { Navigate, Route, Routes, useNavigate } from "react-router-dom";
import Layout from "./components/Layout.jsx";
import HomePage from "./pages/HomePage.jsx";
import CategoryPage from "./pages/CategoryPage.jsx";
import ProductDetailsPage from "./pages/ProductDetailsPage.jsx";
import LoginPage from "./pages/LoginPage.jsx";
import RegisterPage from "./pages/RegisterPage.jsx";
import DashboardPage from "./pages/DashboardPage.jsx";
import WalletPage from "./pages/WalletPage.jsx";
import CartPage from "./pages/CartPage.jsx";
import { products } from "./data/marketData.js";

const startingBalance = 18500;

export default function App() {
  const [cart, setCart] = useState([]);
  const [walletBalance, setWalletBalance] = useState(startingBalance);
  const navigate = useNavigate();

  const cartCount = useMemo(
    () => cart.reduce((total, item) => total + item.quantity, 0),
    [cart]
  );

  const addToCart = (product) => {
    setCart((items) => {
      const existing = items.find((item) => item.id === product.id);
      if (existing) {
        return items.map((item) =>
          item.id === product.id ? { ...item, quantity: item.quantity + 1 } : item
        );
      }
      return [...items, { ...product, quantity: 1 }];
    });
    navigate("/cart");
  };

  const updateQuantity = (id, nextQuantity) => {
    setCart((items) =>
      items
        .map((item) =>
          item.id === id ? { ...item, quantity: Math.max(1, nextQuantity) } : item
        )
        .filter((item) => item.quantity > 0)
    );
  };

  const removeFromCart = (id) => {
    setCart((items) => items.filter((item) => item.id !== id));
  };

  const addDeposit = (amount) => {
    setWalletBalance((balance) => balance + amount);
  };

  return (
    <Layout cartCount={cartCount}>
      <Routes>
        <Route path="/" element={<HomePage onBuy={addToCart} />} />
        <Route path="/category/:slug" element={<CategoryPage onBuy={addToCart} />} />
        <Route
          path="/product/:id"
          element={<ProductDetailsPage products={products} onBuy={addToCart} />}
        />
        <Route path="/login" element={<LoginPage />} />
        <Route path="/register" element={<RegisterPage />} />
        <Route
          path="/dashboard"
          element={<DashboardPage walletBalance={walletBalance} cartCount={cartCount} />}
        />
        <Route
          path="/wallet"
          element={<WalletPage balance={walletBalance} onDeposit={addDeposit} />}
        />
        <Route
          path="/cart"
          element={
            <CartPage
              balance={walletBalance}
              cart={cart}
              onQuantityChange={updateQuantity}
              onRemove={removeFromCart}
            />
          }
        />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </Layout>
  );
}
