import { Link, useParams } from "react-router-dom";
import ProductCard from "../components/ProductCard.jsx";
import { categories, products } from "../data/marketData.js";

export default function CategoryPage({ onBuy }) {
  const { slug } = useParams();
  const category = categories.find((item) => item.slug === slug);
  const categoryProducts = products.filter((product) => product.slug === slug);
  const visibleProducts = categoryProducts.length ? categoryProducts : products.slice(0, 3);

  return (
    <div>
      <div className="px-3 py-2 text-sm text-gray-600">
        <Link to="/" className="text-gray-600">
          Home
        </Link>{" "}
        / {category?.name ?? "Category"}
      </div>
      <section>
        <div className="bg-market-dark px-3 py-2 text-sm font-bold text-white">
          Social Media Services / {category?.name ?? "Featured"}
        </div>
        {categoryProducts.length === 0 && (
          <div className="border-x border-b border-market-line bg-white px-3 py-3 text-sm text-gray-600">
            New marketplace listings for this category are being prepared. Featured packages are
            shown below.
          </div>
        )}
        <div className="border-x border-market-line">
          {visibleProducts.map((product) => (
            <ProductCard key={product.id} product={product} onBuy={onBuy} />
          ))}
        </div>
      </section>
    </div>
  );
}
