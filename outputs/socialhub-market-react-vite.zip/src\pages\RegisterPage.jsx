import { Link } from "react-router-dom";

export default function RegisterPage() {
  return (
    <div>
      <div className="bg-market-dark px-3 py-2 text-sm font-bold text-white">Register</div>
      <form className="space-y-3 border-x border-b border-market-line bg-white p-3">
        <label className="block">
          <span className="text-xs font-bold text-gray-600">Full name</span>
          <input
            className="mt-1 h-11 w-full rounded border border-gray-300 px-3 outline-none focus:border-market-green"
            placeholder="Your name"
          />
        </label>
        <label className="block">
          <span className="text-xs font-bold text-gray-600">Email</span>
          <input
            type="email"
            className="mt-1 h-11 w-full rounded border border-gray-300 px-3 outline-none focus:border-market-green"
            placeholder="you@example.com"
          />
        </label>
        <label className="block">
          <span className="text-xs font-bold text-gray-600">Access code</span>
          <input
            type="text"
            className="mt-1 h-11 w-full rounded border border-gray-300 px-3 outline-none focus:border-market-green"
            placeholder="Create access code"
          />
        </label>
        <Link
          to="/dashboard"
          className="tap-highlight flex h-11 w-full items-center justify-center rounded bg-market-green text-sm font-bold text-white"
        >
          Create account
        </Link>
      </form>
    </div>
  );
}
