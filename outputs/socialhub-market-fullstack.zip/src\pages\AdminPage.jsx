import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { adminApi, catalogApi } from "../api/client.js";
import { formatNaira } from "../data/marketData.js";

const emptyProduct = {
  categoryId: "",
  title: "",
  description: "",
  price: "",
  stock: "",
  platform: "",
  deliveryTime: "48h",
  rating: 4.8,
  orderCount: 0,
  isActive: true,
};

export default function AdminPage({ user, categories, onCatalogRefresh }) {
  const [deposits, setDeposits] = useState([]);
  const [orders, setOrders] = useState([]);
  const [products, setProducts] = useState([]);
  const [productForm, setProductForm] = useState(emptyProduct);
  const [editingId, setEditingId] = useState("");
  const [message, setMessage] = useState("");

  const loadAdminData = async () => {
    const [depositData, orderData, productData] = await Promise.all([
      adminApi.deposits(),
      adminApi.orders(),
      catalogApi.products(),
    ]);
    setDeposits(depositData.deposits);
    setOrders(orderData.orders);
    setProducts(productData.products);
  };

  useEffect(() => {
    if (user?.role !== "ADMIN") return;
    loadAdminData().catch((error) => setMessage(error.message));
  }, [user]);

  if (!user) {
    return <Gate message="Login with an admin account to continue." />;
  }

  if (user.role !== "ADMIN") {
    return <Gate message="Admin access is required." />;
  }

  const pendingDeposits = deposits.filter((deposit) => deposit.status === "PENDING");

  const handleDeposit = async (id, action) => {
    setMessage("");
    try {
      if (action === "approve") await adminApi.approveDeposit(id);
      else await adminApi.rejectDeposit(id);
      await loadAdminData();
      setMessage(`Deposit ${action}d.`);
    } catch (error) {
      setMessage(error.message);
    }
  };

  const saveProduct = async (event) => {
    event.preventDefault();
    setMessage("");
    try {
      const payload = {
        ...productForm,
        price: Number(productForm.price),
        stock: Number(productForm.stock),
        rating: Number(productForm.rating),
        orderCount: Number(productForm.orderCount || 0),
      };
      if (editingId) {
        await adminApi.updateProduct(editingId, payload);
        setMessage("Product updated.");
      } else {
        await adminApi.createProduct(payload);
        setMessage("Product created.");
      }
      setProductForm(emptyProduct);
      setEditingId("");
      await loadAdminData();
      await onCatalogRefresh();
    } catch (error) {
      setMessage(error.message);
    }
  };

  const editProduct = (product) => {
    setEditingId(product.id);
    setProductForm({
      categoryId: product.categoryId,
      title: product.title,
      description: product.description,
      price: product.price,
      stock: product.stock,
      platform: product.platform,
      deliveryTime: product.deliveryTime,
      rating: product.rating,
      orderCount: product.orderCount,
      isActive: product.isActive,
    });
  };

  const disableProduct = async (id) => {
    setMessage("");
    try {
      await adminApi.deleteProduct(id);
      await loadAdminData();
      await onCatalogRefresh();
      setMessage("Product disabled.");
    } catch (error) {
      setMessage(error.message);
    }
  };

  return (
    <div>
      <div className="bg-market-dark px-3 py-2 text-sm font-bold text-white">Admin Dashboard</div>
      {message && (
        <div className="border-x border-b border-market-line bg-white px-3 py-3 text-sm font-semibold text-gray-700">
          {message}
        </div>
      )}

      <section className="mt-3">
        <div className="bg-market-dark px-3 py-2 text-sm font-bold text-white">Pending Deposits</div>
        <div className="border-x border-market-line bg-white">
          {pendingDeposits.length === 0 && (
            <div className="border-b border-market-line px-3 py-3 text-sm text-gray-600">
              No pending deposits.
            </div>
          )}
          {pendingDeposits.map((deposit) => (
            <div key={deposit.id} className="border-b border-market-line px-3 py-3">
              <div className="flex items-start justify-between gap-3">
                <div>
                  <p className="text-sm font-bold text-gray-900">{deposit.user?.email}</p>
                  <p className="text-xs text-gray-500">{deposit.reference}</p>
                  <p className="mt-1 text-sm font-semibold text-gray-700">
                    {deposit.method.replace("_", " ")} - {formatNaira(deposit.amount)}
                  </p>
                </div>
                <div className="flex flex-col gap-2">
                  <button
                    type="button"
                    onClick={() => handleDeposit(deposit.id, "approve")}
                    className="h-9 rounded bg-market-green px-3 text-xs font-bold text-white"
                  >
                    Approve
                  </button>
                  <button
                    type="button"
                    onClick={() => handleDeposit(deposit.id, "reject")}
                    className="h-9 rounded bg-gray-200 px-3 text-xs font-bold text-gray-800"
                  >
                    Reject
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      <section className="mt-3">
        <div className="bg-market-dark px-3 py-2 text-sm font-bold text-white">
          {editingId ? "Edit Product" : "Create Product"}
        </div>
        <form onSubmit={saveProduct} className="space-y-2 border-x border-b border-market-line bg-white p-3">
          <select
            value={productForm.categoryId}
            onChange={(event) => setProductForm((form) => ({ ...form, categoryId: event.target.value }))}
            className="h-11 w-full rounded border border-gray-300 bg-white px-3 text-sm"
            required
          >
            <option value="">Select category</option>
            {categories.map((category) => (
              <option key={category.id} value={category.id}>
                {category.name}
              </option>
            ))}
          </select>
          <input
            value={productForm.title}
            onChange={(event) => setProductForm((form) => ({ ...form, title: event.target.value }))}
            className="h-11 w-full rounded border border-gray-300 px-3 text-sm"
            placeholder="Product title"
            required
          />
          <textarea
            value={productForm.description}
            onChange={(event) => setProductForm((form) => ({ ...form, description: event.target.value }))}
            className="min-h-20 w-full rounded border border-gray-300 px-3 py-2 text-sm"
            placeholder="Service/package description"
            required
          />
          <div className="grid grid-cols-2 gap-2">
            <input
              type="number"
              value={productForm.price}
              onChange={(event) => setProductForm((form) => ({ ...form, price: event.target.value }))}
              className="h-11 rounded border border-gray-300 px-3 text-sm"
              placeholder="Price"
              required
            />
            <input
              type="number"
              value={productForm.stock}
              onChange={(event) => setProductForm((form) => ({ ...form, stock: event.target.value }))}
              className="h-11 rounded border border-gray-300 px-3 text-sm"
              placeholder="Stock"
              required
            />
          </div>
          <div className="grid grid-cols-2 gap-2">
            <input
              value={productForm.platform}
              onChange={(event) => setProductForm((form) => ({ ...form, platform: event.target.value }))}
              className="h-11 rounded border border-gray-300 px-3 text-sm"
              placeholder="Platform"
              required
            />
            <input
              value={productForm.deliveryTime}
              onChange={(event) => setProductForm((form) => ({ ...form, deliveryTime: event.target.value }))}
              className="h-11 rounded border border-gray-300 px-3 text-sm"
              placeholder="Delivery"
              required
            />
          </div>
          <button type="submit" className="h-11 w-full rounded bg-market-green text-sm font-bold text-white">
            {editingId ? "Save Product" : "Create Product"}
          </button>
          {editingId && (
            <button
              type="button"
              onClick={() => {
                setEditingId("");
                setProductForm(emptyProduct);
              }}
              className="h-10 w-full rounded bg-gray-100 text-sm font-bold text-gray-800"
            >
              Cancel Edit
            </button>
          )}
        </form>
      </section>

      <section className="mt-3">
        <div className="bg-market-dark px-3 py-2 text-sm font-bold text-white">Products</div>
        <div className="border-x border-market-line bg-white">
          {products.map((product) => (
            <div key={product.id} className="border-b border-market-line px-3 py-3">
              <p className="text-sm font-bold text-gray-900">{product.title}</p>
              <p className="text-xs text-gray-500">
                {product.platform} - {formatNaira(product.price)} - {product.stock} pcs.
              </p>
              <div className="mt-2 flex gap-2">
                <button
                  type="button"
                  onClick={() => editProduct(product)}
                  className="h-9 rounded bg-gray-100 px-3 text-xs font-bold text-gray-800"
                >
                  Edit
                </button>
                <button
                  type="button"
                  onClick={() => disableProduct(product.id)}
                  className="h-9 rounded bg-gray-200 px-3 text-xs font-bold text-gray-800"
                >
                  Disable
                </button>
              </div>
            </div>
          ))}
        </div>
      </section>

      <section className="mt-3">
        <div className="bg-market-dark px-3 py-2 text-sm font-bold text-white">Orders</div>
        <div className="border-x border-market-line bg-white">
          {orders.map((order) => (
            <div key={order.id} className="border-b border-market-line px-3 py-3">
              <div className="flex items-start justify-between gap-3">
                <div className="min-w-0">
                  <p className="text-sm font-bold text-gray-900">{order.user?.email}</p>
                  <p className="text-xs text-gray-500">{order.id}</p>
                  <p className="mt-1 text-xs text-gray-600">
                    {order.items?.map((item) => `${item.quantity}x ${item.product.title}`).join(", ")}
                  </p>
                </div>
                <div className="text-right">
                  <p className="text-sm font-black text-gray-900">{formatNaira(order.totalAmount)}</p>
                  <p className="text-xs font-bold text-market-green">{order.status}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}

function Gate({ message }) {
  return (
    <div>
      <div className="bg-market-dark px-3 py-2 text-sm font-bold text-white">Admin Dashboard</div>
      <section className="border-x border-b border-market-line bg-white p-4">
        <p className="text-sm text-gray-600">{message}</p>
        <Link className="mt-3 inline-flex h-10 items-center rounded bg-market-green px-4 text-sm font-bold text-white" to="/login">
          Login
        </Link>
      </section>
    </div>
  );
}
