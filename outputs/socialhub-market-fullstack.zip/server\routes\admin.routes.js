import { Router } from "express";
import { requireAdmin, requireAuth } from "../middleware/auth.js";
import { prisma } from "../prisma.js";
import { ApiError, asyncHandler } from "../utils/errors.js";
import { depositDto, orderDto, productDto, publicUser } from "../utils/format.js";
import { validate } from "../utils/validation.js";
import {
  categoryCreateSchema,
  categoryUpdateSchema,
  productCreateSchema,
  productUpdateSchema,
} from "../validators/admin.validators.js";

const router = Router();

router.use(requireAuth, requireAdmin);

router.get(
  "/users",
  asyncHandler(async (req, res) => {
    const users = await prisma.user.findMany({ orderBy: { createdAt: "desc" } });
    res.json({ users: users.map(publicUser) });
  })
);

router.get(
  "/deposits",
  asyncHandler(async (req, res) => {
    const deposits = await prisma.deposit.findMany({
      include: { user: true },
      orderBy: { createdAt: "desc" },
    });
    res.json({ deposits: deposits.map(depositDto) });
  })
);

router.patch(
  "/deposits/:id/approve",
  asyncHandler(async (req, res) => {
    const deposit = await prisma.$transaction(async (tx) => {
      const current = await tx.deposit.findUnique({ where: { id: req.params.id } });
      if (!current) throw new ApiError(404, "Deposit not found.");
      if (current.status !== "PENDING") {
        throw new ApiError(400, "Only pending deposits can be approved.");
      }

      await tx.user.update({
        where: { id: current.userId },
        data: { walletBalance: { increment: current.amount } },
      });

      return tx.deposit.update({
        where: { id: current.id },
        data: { status: "APPROVED" },
        include: { user: true },
      });
    });
    res.json({ deposit: depositDto(deposit) });
  })
);

router.patch(
  "/deposits/:id/reject",
  asyncHandler(async (req, res) => {
    const deposit = await prisma.deposit.findUnique({ where: { id: req.params.id } });
    if (!deposit) throw new ApiError(404, "Deposit not found.");
    if (deposit.status !== "PENDING") {
      throw new ApiError(400, "Only pending deposits can be rejected.");
    }

    const updated = await prisma.deposit.update({
      where: { id: req.params.id },
      data: { status: "REJECTED" },
      include: { user: true },
    });
    res.json({ deposit: depositDto(updated) });
  })
);

router.post(
  "/categories",
  validate(categoryCreateSchema),
  asyncHandler(async (req, res) => {
    const category = await prisma.category.create({ data: req.body });
    res.status(201).json({ category });
  })
);

router.patch(
  "/categories/:id",
  validate(categoryUpdateSchema),
  asyncHandler(async (req, res) => {
    const category = await prisma.category.update({
      where: { id: req.params.id },
      data: req.body,
    });
    res.json({ category });
  })
);

router.delete(
  "/categories/:id",
  asyncHandler(async (req, res) => {
    await prisma.category.delete({ where: { id: req.params.id } });
    res.json({ message: "Category deleted." });
  })
);

router.post(
  "/products",
  validate(productCreateSchema),
  asyncHandler(async (req, res) => {
    const product = await prisma.product.create({
      data: req.body,
      include: { category: true },
    });
    res.status(201).json({ product: productDto(product) });
  })
);

router.patch(
  "/products/:id",
  validate(productUpdateSchema),
  asyncHandler(async (req, res) => {
    const product = await prisma.product.update({
      where: { id: req.params.id },
      data: req.body,
      include: { category: true },
    });
    res.json({ product: productDto(product) });
  })
);

router.delete(
  "/products/:id",
  asyncHandler(async (req, res) => {
    await prisma.product.update({
      where: { id: req.params.id },
      data: { isActive: false },
    });
    res.json({ message: "Product disabled." });
  })
);

router.get(
  "/orders",
  asyncHandler(async (req, res) => {
    const orders = await prisma.order.findMany({
      include: { user: true, items: { include: { product: true } } },
      orderBy: { createdAt: "desc" },
    });
    res.json({ orders: orders.map(orderDto) });
  })
);

export default router;
