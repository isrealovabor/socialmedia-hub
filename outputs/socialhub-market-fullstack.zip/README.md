# SocialHub Market

Mobile-first legal digital services marketplace built with React, Vite, Tailwind CSS, Express, PostgreSQL, Prisma, and JWT auth.

The marketplace is for digital marketing services, social media growth packages, content packs, consulting, and verified transfer assistance where legally allowed.

## Run Locally

1. Install dependencies:

```bash
npm install
```

2. Create `.env` from the example file:

```bash
cp .env.example .env
```

Update `DATABASE_URL` for your local PostgreSQL database and set a long random `JWT_SECRET`.

3. Create the database tables:

```bash
npx prisma migrate dev
```

4. Seed demo data:

```bash
npx prisma db seed
```

5. Start the backend and frontend together:

```bash
npm run dev
```

Frontend: `http://127.0.0.1:5173`  
Backend API: `http://127.0.0.1:4000/api`

## Demo Accounts

Admin:

```text
email: admin@socialhub.test
password: Admin123!
```

User:

```text
email: user@socialhub.test
password: User123!
```

## Environment Variables

```text
DATABASE_URL="postgresql://postgres:postgres@localhost:5432/socialhub_market?schema=public"
JWT_SECRET="replace-this-with-a-long-random-secret"
PORT=4000
CLIENT_URL="http://127.0.0.1:5173"
VITE_API_URL="http://127.0.0.1:4000/api"
```

## Main API Routes

Auth:

```text
POST /api/auth/register
POST /api/auth/login
GET /api/auth/me
```

Products:

```text
GET /api/categories
GET /api/products
GET /api/products/:id
GET /api/categories/:slug/products
```

Wallet and deposits:

```text
GET /api/wallet
POST /api/deposits
GET /api/deposits/my
```

Orders:

```text
POST /api/orders
GET /api/orders/my
GET /api/orders/:id
```

Admin:

```text
GET /api/admin/users
GET /api/admin/deposits
PATCH /api/admin/deposits/:id/approve
PATCH /api/admin/deposits/:id/reject
POST /api/admin/categories
PATCH /api/admin/categories/:id
DELETE /api/admin/categories/:id
POST /api/admin/products
PATCH /api/admin/products/:id
DELETE /api/admin/products/:id
GET /api/admin/orders
```

## Project Structure

```text
src/
  api/
  components/
  data/
  pages/
server/
  middleware/
  routes/
  utils/
  validators/
prisma/
  schema.prisma
  seed.js
```

## Notes

- User routes require `Authorization: Bearer <token>`.
- Admin routes require an authenticated user with `ADMIN` role.
- Deposit requests start as `PENDING`; admin approval credits the user wallet.
- Checkout validates wallet balance and product stock before creating a completed order.
