import { useEffect, useMemo, useState } from "react";
import { Navigate, Route, Routes, useNavigate } from "react-router-dom";
import Layout from "./components/Layout.jsx";
import HomePage from "./pages/HomePage.jsx";
import CategoryPage from "./pages/CategoryPage.jsx";
import ProductDetailsPage from "./pages/ProductDetailsPage.jsx";
import LoginPage from "./pages/LoginPage.jsx";
import RegisterPage from "./pages/RegisterPage.jsx";
import DashboardPage from "./pages/DashboardPage.jsx";
import WalletPage from "./pages/WalletPage.jsx";
import CartPage from "./pages/CartPage.jsx";
import AdminPage from "./pages/AdminPage.jsx";
import { authApi, catalogApi, clearToken } from "./api/client.js";

export default function App() {
  const [cart, setCart] = useState([]);
  const [user, setUser] = useState(null);
  const [products, setProducts] = useState([]);
  const [categories, setCategories] = useState([]);
  const [loadingCatalog, setLoadingCatalog] = useState(true);
  const navigate = useNavigate();

  const cartCount = useMemo(
    () => cart.reduce((total, item) => total + item.quantity, 0),
    [cart]
  );

  const refreshUser = async () => {
    try {
      const data = await authApi.me();
      setUser(data.user);
      return data.user;
    } catch {
      clearToken();
      setUser(null);
      return null;
    }
  };

  const refreshCatalog = async () => {
    setLoadingCatalog(true);
    try {
      const [categoryData, productData] = await Promise.all([
        catalogApi.categories(),
        catalogApi.products(),
      ]);
      setCategories(categoryData.categories);
      setProducts(productData.products);
    } finally {
      setLoadingCatalog(false);
    }
  };

  useEffect(() => {
    refreshUser();
    refreshCatalog();
  }, []);

  const addToCart = (product) => {
    setCart((items) => {
      const existing = items.find((item) => item.id === product.id);
      if (existing) {
        return items.map((item) =>
          item.id === product.id ? { ...item, quantity: item.quantity + 1 } : item
        );
      }
      return [...items, { ...product, quantity: 1 }];
    });
    navigate("/cart");
  };

  const updateQuantity = (id, nextQuantity) => {
    setCart((items) =>
      items
        .map((item) =>
          item.id === id ? { ...item, quantity: Math.max(1, nextQuantity) } : item
        )
        .filter((item) => item.quantity > 0)
    );
  };

  const removeFromCart = (id) => {
    setCart((items) => items.filter((item) => item.id !== id));
  };

  const handleAuth = ({ token, user: nextUser }) => {
    setUser(nextUser);
    navigate(nextUser.role === "ADMIN" ? "/admin" : "/dashboard");
  };

  const handleLogout = () => {
    clearToken();
    setUser(null);
    navigate("/login");
  };

  return (
    <Layout cartCount={cartCount} categories={categories}>
      <Routes>
        <Route
          path="/"
          element={<HomePage products={products} loading={loadingCatalog} onBuy={addToCart} />}
        />
        <Route path="/category/:slug" element={<CategoryPage onBuy={addToCart} />} />
        <Route
          path="/product/:id"
          element={<ProductDetailsPage products={products} onBuy={addToCart} />}
        />
        <Route path="/login" element={<LoginPage onAuth={handleAuth} />} />
        <Route path="/register" element={<RegisterPage onAuth={handleAuth} />} />
        <Route
          path="/dashboard"
          element={<DashboardPage user={user} cartCount={cartCount} onLogout={handleLogout} />}
        />
        <Route
          path="/wallet"
          element={<WalletPage user={user} onUserRefresh={refreshUser} />}
        />
        <Route
          path="/cart"
          element={
            <CartPage
              user={user}
              cart={cart}
              onClearCart={() => setCart([])}
              onUserRefresh={refreshUser}
              onCatalogRefresh={refreshCatalog}
              onQuantityChange={updateQuantity}
              onRemove={removeFromCart}
            />
          }
        />
        <Route
          path="/admin"
          element={<AdminPage user={user} categories={categories} onCatalogRefresh={refreshCatalog} />}
        />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </Layout>
  );
}
