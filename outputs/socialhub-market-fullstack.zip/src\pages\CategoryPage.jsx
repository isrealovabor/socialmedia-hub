import { useEffect, useState } from "react";
import { Link, useParams } from "react-router-dom";
import ProductCard from "../components/ProductCard.jsx";
import { catalogApi } from "../api/client.js";

export default function CategoryPage({ onBuy }) {
  const { slug } = useParams();
  const [category, setCategory] = useState(null);
  const [products, setProducts] = useState([]);
  const [message, setMessage] = useState("Loading products...");

  useEffect(() => {
    let active = true;
    setMessage("Loading products...");
    catalogApi
      .categoryProducts(slug)
      .then((data) => {
        if (!active) return;
        setCategory(data.category);
        setProducts(data.products);
        setMessage(data.products.length ? "" : "No active products in this category yet.");
      })
      .catch((error) => {
        if (!active) return;
        setMessage(error.message);
        setProducts([]);
      });
    return () => {
      active = false;
    };
  }, [slug]);

  return (
    <div>
      <div className="px-3 py-2 text-sm text-gray-600">
        <Link to="/" className="text-gray-600">
          Home
        </Link>{" "}
        / {category?.name ?? "Category"}
      </div>
      <section>
        <div className="bg-market-dark px-3 py-2 text-sm font-bold text-white">
          Social Media Services / {category?.name ?? "Featured"}
        </div>
        {message && (
          <div className="border-x border-b border-market-line bg-white px-3 py-3 text-sm text-gray-600">
            {message}
          </div>
        )}
        <div className="border-x border-market-line">
          {products.map((product) => (
            <ProductCard key={product.id} product={product} onBuy={onBuy} />
          ))}
        </div>
      </section>
    </div>
  );
}
