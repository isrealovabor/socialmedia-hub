import { Minus, Plus, Trash2 } from "lucide-react";
import { Link } from "react-router-dom";
import { useState } from "react";
import { orderApi } from "../api/client.js";
import { formatNaira } from "../data/marketData.js";

export default function CartPage({
  cart,
  user,
  onQuantityChange,
  onRemove,
  onClearCart,
  onUserRefresh,
  onCatalogRefresh,
}) {
  const [message, setMessage] = useState("");
  const total = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const balance = user?.walletBalance ?? 0;
  const insufficient = cart.length > 0 && total > balance;

  const checkout = async () => {
    setMessage("");
    if (!user) {
      setMessage("Login to checkout.");
      return;
    }
    try {
      await orderApi.checkout(
        cart.map((item) => ({
          productId: item.id,
          quantity: item.quantity,
        }))
      );
      setMessage("Checkout completed.");
      onClearCart();
      await onUserRefresh();
      await onCatalogRefresh();
    } catch (error) {
      setMessage(error.message);
    }
  };

  return (
    <div>
      <div className="bg-market-dark px-3 py-2 text-sm font-bold text-white">Cart</div>
      {cart.length === 0 ? (
        <section className="border-x border-b border-market-line bg-white p-4 text-center">
          <p className="text-sm text-gray-600">Your cart is empty.</p>
          <Link
            to="/"
            className="mt-3 inline-flex h-10 items-center justify-center rounded bg-market-green px-4 text-sm font-bold text-white"
          >
            Browse packages
          </Link>
        </section>
      ) : (
        <>
          <div className="border-x border-market-line bg-white">
            {cart.map((item) => (
              <article key={item.id} className="border-b border-market-line p-3">
                <div className="flex gap-3">
                  <div
                    className={`flex h-11 w-11 shrink-0 items-center justify-center rounded text-xs font-black text-white ${item.color || "bg-gray-700"}`}
                  >
                    {item.icon || item.platform?.slice(0, 2) || "SH"}
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="text-sm font-bold leading-snug text-gray-900">{item.title}</p>
                    <p className="mt-1 text-sm font-semibold text-gray-700">{formatNaira(item.price)}</p>
                  </div>
                  <button
                    type="button"
                    aria-label="Remove item"
                    onClick={() => onRemove(item.id)}
                    className="tap-highlight flex h-9 w-9 items-center justify-center rounded text-gray-500"
                  >
                    <Trash2 size={18} />
                  </button>
                </div>
                <div className="mt-3 flex items-center justify-between">
                  <div className="flex h-9 items-center overflow-hidden rounded border border-gray-300">
                    <button
                      type="button"
                      aria-label="Decrease quantity"
                      onClick={() => onQuantityChange(item.id, item.quantity - 1)}
                      className="tap-highlight flex h-9 w-10 items-center justify-center bg-gray-50"
                    >
                      <Minus size={16} />
                    </button>
                    <span className="flex h-9 w-12 items-center justify-center text-sm font-bold">
                      {item.quantity}
                    </span>
                    <button
                      type="button"
                      aria-label="Increase quantity"
                      onClick={() => onQuantityChange(item.id, item.quantity + 1)}
                      className="tap-highlight flex h-9 w-10 items-center justify-center bg-gray-50"
                    >
                      <Plus size={16} />
                    </button>
                  </div>
                  <p className="text-sm font-black text-gray-900">
                    {formatNaira(item.price * item.quantity)}
                  </p>
                </div>
              </article>
            ))}
          </div>
          <section className="mt-3 border-x border-b border-market-line bg-white p-3">
            <div className="flex items-center justify-between text-sm font-bold text-gray-700">
              <span>Wallet balance</span>
              <span>{formatNaira(balance)}</span>
            </div>
            <div className="mt-2 flex items-center justify-between text-lg font-black text-gray-900">
              <span>Total</span>
              <span>{formatNaira(total)}</span>
            </div>
            {insufficient && (
              <p className="mt-3 rounded border border-yellow-300 bg-yellow-50 px-3 py-2 text-sm font-semibold text-yellow-800">
                Insufficient balance. Please deposit funds.
              </p>
            )}
            {message && (
              <p className="mt-3 rounded border border-gray-200 bg-gray-50 px-3 py-2 text-sm font-semibold text-gray-700">
                {message}
              </p>
            )}
            <button
              type="button"
              onClick={checkout}
              disabled={insufficient}
              className="tap-highlight mt-3 h-11 w-full rounded bg-market-green text-sm font-bold text-white disabled:bg-gray-300 disabled:text-gray-600"
            >
              Checkout
            </button>
          </section>
        </>
      )}
    </div>
  );
}
