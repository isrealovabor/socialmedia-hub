import { useState } from "react";
import { Link } from "react-router-dom";
import { authApi, setToken } from "../api/client.js";

export default function LoginPage({ onAuth }) {
  const [form, setForm] = useState({ email: "", password: "" });
  const [message, setMessage] = useState("");

  const submit = async (event) => {
    event.preventDefault();
    setMessage("");
    try {
      const data = await authApi.login(form);
      setToken(data.token);
      onAuth(data);
    } catch (error) {
      setMessage(error.message);
    }
  };

  return (
    <div>
      <div className="bg-market-dark px-3 py-2 text-sm font-bold text-white">Login</div>
      <form onSubmit={submit} className="space-y-3 border-x border-b border-market-line bg-white p-3">
        <label className="block">
          <span className="text-xs font-bold text-gray-600">Email</span>
          <input
            type="email"
            value={form.email}
            onChange={(event) => setForm((current) => ({ ...current, email: event.target.value }))}
            className="mt-1 h-11 w-full rounded border border-gray-300 px-3 outline-none focus:border-market-green"
            placeholder="you@example.com"
          />
        </label>
        <label className="block">
          <span className="text-xs font-bold text-gray-600">Access code</span>
          <input
            type="text"
            value={form.password}
            onChange={(event) => setForm((current) => ({ ...current, password: event.target.value }))}
            className="mt-1 h-11 w-full rounded border border-gray-300 px-3 outline-none focus:border-market-green"
            placeholder="Enter access code"
          />
        </label>
        <button
          type="submit"
          className="tap-highlight h-11 w-full rounded bg-market-green text-sm font-bold text-white"
        >
          Login
        </button>
        {message && <p className="text-sm font-semibold text-red-600">{message}</p>}
        <p className="text-center text-sm text-gray-600">
          New here?{" "}
          <Link to="/register" className="font-bold text-market-green">
            Create an account
          </Link>
        </p>
      </form>
    </div>
  );
}
