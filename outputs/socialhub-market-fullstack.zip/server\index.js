import "dotenv/config";
import express from "express";
import cors from "cors";
import { authLimiter } from "./middleware/rateLimit.js";
import { errorHandler, notFound } from "./middleware/error.js";
import authRoutes from "./routes/auth.routes.js";
import productRoutes from "./routes/product.routes.js";
import walletRoutes from "./routes/wallet.routes.js";
import orderRoutes from "./routes/order.routes.js";
import adminRoutes from "./routes/admin.routes.js";

const app = express();
const port = process.env.PORT || 4000;

app.use(
  cors({
    origin: process.env.CLIENT_URL || "http://127.0.0.1:5173",
  })
);
app.use(express.json({ limit: "1mb" }));

app.get("/api/health", (req, res) => {
  res.json({ ok: true, name: "SocialHub Market API" });
});

app.use("/api/auth", authLimiter, authRoutes);
app.use("/api", productRoutes);
app.use("/api", walletRoutes);
app.use("/api", orderRoutes);
app.use("/api/admin", adminRoutes);
app.use(notFound);
app.use(errorHandler);

app.listen(port, () => {
  console.log(`SocialHub Market API listening on port ${port}`);
});
