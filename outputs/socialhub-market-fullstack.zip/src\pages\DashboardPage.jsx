import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { LogOut, PackageCheck, ShoppingCart, WalletCards } from "lucide-react";
import { orderApi } from "../api/client.js";
import { formatNaira } from "../data/marketData.js";

export default function DashboardPage({ user, cartCount, onLogout }) {
  const [orders, setOrders] = useState([]);
  const [message, setMessage] = useState("");

  useEffect(() => {
    if (!user) return;
    orderApi
      .myOrders()
      .then((data) => setOrders(data.orders))
      .catch((error) => setMessage(error.message));
  }, [user]);

  if (!user) {
    return (
      <div>
        <div className="bg-market-dark px-3 py-2 text-sm font-bold text-white">Dashboard</div>
        <section className="border-x border-b border-market-line bg-white p-4">
          <p className="text-sm text-gray-600">Login to view your wallet and orders.</p>
          <Link className="mt-3 inline-flex h-10 items-center rounded bg-market-green px-4 text-sm font-bold text-white" to="/login">
            Login
          </Link>
        </section>
      </div>
    );
  }

  return (
    <div>
      <div className="bg-market-dark px-3 py-2 text-sm font-bold text-white">Dashboard</div>
      <section className="border-x border-b border-market-line bg-white p-3">
        <p className="text-xs font-bold uppercase text-gray-500">Wallet balance</p>
        <p className="mt-1 text-3xl font-black text-gray-900">{formatNaira(user.walletBalance)}</p>
        <p className="mt-1 text-sm font-semibold text-gray-600">{user.name}</p>
        <div className="mt-4 grid grid-cols-2 gap-2">
          <QuickButton to="/wallet" icon={WalletCards} label="Deposit" />
          <QuickButton to="/dashboard" icon={PackageCheck} label="Orders" />
          <QuickButton to="/cart" icon={ShoppingCart} label={`Cart ${cartCount ? cartCount : ""}`} />
          {user.role === "ADMIN" && <QuickButton to="/admin" icon={PackageCheck} label="Admin" />}
          <button
            type="button"
            onClick={onLogout}
            className="tap-highlight flex h-12 items-center justify-center gap-2 rounded border border-gray-200 bg-gray-50 text-sm font-bold text-gray-800"
          >
            <LogOut size={18} className="text-market-green" />
            Logout
          </button>
        </div>
      </section>
      <section className="mt-3">
        <div className="bg-market-dark px-3 py-2 text-sm font-bold text-white">Recent Orders</div>
        <div className="border-x border-market-line bg-white">
          {message && <div className="border-b border-market-line px-3 py-3 text-sm text-red-600">{message}</div>}
          {!orders.length && !message && (
            <div className="border-b border-market-line px-3 py-3 text-sm text-gray-600">
              No recent orders yet.
            </div>
          )}
          {orders.map((order) => (
            <div key={order.id} className="border-b border-market-line px-3 py-3">
              <div className="flex items-start justify-between gap-3">
                <div className="min-w-0">
                  <p className="text-sm font-bold text-gray-900">
                    {order.item || order.items?.map((item) => item.product.title).join(", ")}
                  </p>
                  <p className="text-xs text-gray-500">{order.id}</p>
                </div>
                <span className="rounded bg-gray-100 px-2 py-1 text-xs font-bold text-gray-700">
                  {order.status}
                </span>
              </div>
              <p className="mt-1 text-sm font-semibold text-gray-700">
                {formatNaira(order.total ?? order.totalAmount)}
              </p>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}

function QuickButton({ to, icon: Icon, label }) {
  return (
    <Link
      to={to}
      className="tap-highlight flex h-12 items-center justify-center gap-2 rounded border border-gray-200 bg-gray-50 text-sm font-bold text-gray-800"
    >
      <Icon size={18} className="text-market-green" />
      {label}
    </Link>
  );
}
