import { Prisma } from "@prisma/client";
import { Router } from "express";
import { requireAuth } from "../middleware/auth.js";
import { prisma } from "../prisma.js";
import { ApiError, asyncHandler } from "../utils/errors.js";
import { orderDto } from "../utils/format.js";
import { validate } from "../utils/validation.js";
import { checkoutSchema } from "../validators/order.validators.js";

const router = Router();

router.post(
  "/orders",
  requireAuth,
  validate(checkoutSchema),
  asyncHandler(async (req, res) => {
    const order = await prisma.$transaction(async (tx) => {
      const user = await tx.user.findUnique({ where: { id: req.user.id } });
      const ids = req.body.items.map((item) => item.productId);
      const products = await tx.product.findMany({
        where: { id: { in: ids }, isActive: true },
      });

      if (products.length !== ids.length) {
        throw new ApiError(400, "One or more products are unavailable.");
      }

      const productById = new Map(products.map((product) => [product.id, product]));
      let total = new Prisma.Decimal(0);

      for (const item of req.body.items) {
        const product = productById.get(item.productId);
        if (product.stock < item.quantity) {
          throw new ApiError(400, `${product.title} does not have enough stock.`);
        }
        total = total.plus(product.price.mul(item.quantity));
      }

      if (user.walletBalance.lessThan(total)) {
        throw new ApiError(400, "Insufficient balance. Please deposit funds.");
      }

      await tx.user.update({
        where: { id: req.user.id },
        data: { walletBalance: { decrement: total } },
      });

      for (const item of req.body.items) {
        await tx.product.update({
          where: { id: item.productId },
          data: {
            stock: { decrement: item.quantity },
            orderCount: { increment: item.quantity },
          },
        });
      }

      return tx.order.create({
        data: {
          userId: req.user.id,
          totalAmount: total,
          status: "COMPLETED",
          items: {
            create: req.body.items.map((item) => {
              const product = productById.get(item.productId);
              return {
                productId: item.productId,
                quantity: item.quantity,
                unitPrice: product.price,
              };
            }),
          },
        },
        include: { items: { include: { product: true } } },
      });
    });

    res.status(201).json({ order: orderDto(order) });
  })
);

router.get(
  "/orders/my",
  requireAuth,
  asyncHandler(async (req, res) => {
    const orders = await prisma.order.findMany({
      where: { userId: req.user.id },
      include: { items: { include: { product: true } } },
      orderBy: { createdAt: "desc" },
    });
    res.json({ orders: orders.map(orderDto) });
  })
);

router.get(
  "/orders/:id",
  requireAuth,
  asyncHandler(async (req, res) => {
    const order = await prisma.order.findFirst({
      where: { id: req.params.id, userId: req.user.id },
      include: { items: { include: { product: true } } },
    });
    if (!order) {
      throw new ApiError(404, "Order not found.");
    }
    res.json({ order: orderDto(order) });
  })
);

export default router;
