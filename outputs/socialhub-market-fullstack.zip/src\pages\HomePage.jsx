import ProductCard from "../components/ProductCard.jsx";

export default function HomePage({ products, loading, onBuy }) {
  const featured = products.filter((product) => product.category?.slug === "instagram");
  const otherProducts = products.filter((product) => product.category?.slug !== "instagram");

  return (
    <div>
      <div className="bg-market-yellow px-3 py-3 text-sm font-semibold leading-snug text-gray-800">
        News, promotions, coupons, announcements are published here
      </div>
      <div className="px-3 py-2 text-sm text-gray-600">Home</div>
      <section>
        <div className="bg-market-dark px-3 py-2 text-sm font-bold text-white">
          Social Media Services / Instagram
        </div>
        <div className="border-x border-market-line">
          {loading && (
            <div className="border-b border-market-line bg-white px-3 py-4 text-sm text-gray-600">
              Loading marketplace products...
            </div>
          )}
          {featured.map((product) => (
            <ProductCard key={product.id} product={product} onBuy={onBuy} />
          ))}
          {otherProducts.map((product) => (
            <ProductCard key={product.id} product={product} onBuy={onBuy} />
          ))}
        </div>
      </section>
    </div>
  );
}
