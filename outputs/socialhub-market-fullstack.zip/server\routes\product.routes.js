import { Router } from "express";
import { prisma } from "../prisma.js";
import { ApiError, asyncHandler } from "../utils/errors.js";
import { productDto } from "../utils/format.js";

const router = Router();

router.get(
  "/categories",
  asyncHandler(async (req, res) => {
    const categories = await prisma.category.findMany({
      orderBy: { createdAt: "asc" },
    });
    res.json({ categories });
  })
);

router.get(
  "/products",
  asyncHandler(async (req, res) => {
    const products = await prisma.product.findMany({
      where: { isActive: true },
      include: { category: true },
      orderBy: { createdAt: "asc" },
    });
    res.json({ products: products.map(productDto) });
  })
);

router.get(
  "/products/:id",
  asyncHandler(async (req, res) => {
    const product = await prisma.product.findFirst({
      where: { id: req.params.id, isActive: true },
      include: { category: true },
    });
    if (!product) {
      throw new ApiError(404, "Product not found.");
    }
    res.json({ product: productDto(product) });
  })
);

router.get(
  "/categories/:slug/products",
  asyncHandler(async (req, res) => {
    const category = await prisma.category.findUnique({
      where: { slug: req.params.slug },
      include: {
        products: {
          where: { isActive: true },
          orderBy: { createdAt: "asc" },
        },
      },
    });
    if (!category) {
      throw new ApiError(404, "Category not found.");
    }
    res.json({
      category,
      products: category.products.map(productDto),
    });
  })
);

export default router;
