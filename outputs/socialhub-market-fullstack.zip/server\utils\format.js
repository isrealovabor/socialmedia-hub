export function toNumber(value) {
  if (value === null || value === undefined) return value;
  if (typeof value === "number") return value;
  if (typeof value.toNumber === "function") return value.toNumber();
  return Number(value);
}

export function publicUser(user) {
  if (!user) return null;
  return {
    id: user.id,
    name: user.name,
    email: user.email,
    role: user.role,
    walletBalance: toNumber(user.walletBalance),
    createdAt: user.createdAt,
  };
}

export function productDto(product) {
  return {
    ...product,
    price: toNumber(product.price),
    rating: toNumber(product.rating),
  };
}

export function depositDto(deposit) {
  return {
    ...deposit,
    amount: toNumber(deposit.amount),
    user: deposit.user ? publicUser(deposit.user) : undefined,
  };
}

export function orderDto(order) {
  return {
    ...order,
    totalAmount: toNumber(order.totalAmount),
    user: order.user ? publicUser(order.user) : undefined,
    items: order.items?.map((item) => ({
      ...item,
      unitPrice: toNumber(item.unitPrice),
      product: item.product ? productDto(item.product) : undefined,
    })),
  };
}
