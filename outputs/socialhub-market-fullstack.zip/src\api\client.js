const API_URL = import.meta.env.VITE_API_URL || "http://127.0.0.1:4000/api";
const TOKEN_KEY = "socialhub_token";

export function getToken() {
  return localStorage.getItem(TOKEN_KEY);
}

export function setToken(token) {
  localStorage.setItem(TOKEN_KEY, token);
}

export function clearToken() {
  localStorage.removeItem(TOKEN_KEY);
}

export async function apiRequest(path, options = {}) {
  const token = getToken();
  const headers = {
    "Content-Type": "application/json",
    ...options.headers,
  };

  if (token) {
    headers.Authorization = `Bearer ${token}`;
  }

  const response = await fetch(`${API_URL}${path}`, {
    ...options,
    headers,
  });

  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    throw new Error(data.message || "Request failed.");
  }
  return data;
}

export const authApi = {
  register: (payload) =>
    apiRequest("/auth/register", { method: "POST", body: JSON.stringify(payload) }),
  login: (payload) =>
    apiRequest("/auth/login", { method: "POST", body: JSON.stringify(payload) }),
  me: () => apiRequest("/auth/me"),
};

export const catalogApi = {
  categories: () => apiRequest("/categories"),
  products: () => apiRequest("/products"),
  product: (id) => apiRequest(`/products/${id}`),
  categoryProducts: (slug) => apiRequest(`/categories/${slug}/products`),
};

export const walletApi = {
  wallet: () => apiRequest("/wallet"),
  deposits: () => apiRequest("/deposits/my"),
  createDeposit: (payload) =>
    apiRequest("/deposits", { method: "POST", body: JSON.stringify(payload) }),
};

export const orderApi = {
  checkout: (items) => apiRequest("/orders", { method: "POST", body: JSON.stringify({ items }) }),
  myOrders: () => apiRequest("/orders/my"),
};

export const adminApi = {
  users: () => apiRequest("/admin/users"),
  deposits: () => apiRequest("/admin/deposits"),
  approveDeposit: (id) => apiRequest(`/admin/deposits/${id}/approve`, { method: "PATCH" }),
  rejectDeposit: (id) => apiRequest(`/admin/deposits/${id}/reject`, { method: "PATCH" }),
  createCategory: (payload) =>
    apiRequest("/admin/categories", { method: "POST", body: JSON.stringify(payload) }),
  updateCategory: (id, payload) =>
    apiRequest(`/admin/categories/${id}`, { method: "PATCH", body: JSON.stringify(payload) }),
  deleteCategory: (id) => apiRequest(`/admin/categories/${id}`, { method: "DELETE" }),
  createProduct: (payload) =>
    apiRequest("/admin/products", { method: "POST", body: JSON.stringify(payload) }),
  updateProduct: (id, payload) =>
    apiRequest(`/admin/products/${id}`, { method: "PATCH", body: JSON.stringify(payload) }),
  deleteProduct: (id) => apiRequest(`/admin/products/${id}`, { method: "DELETE" }),
  orders: () => apiRequest("/admin/orders"),
};
