export function notFound(req, res, next) {
  res.status(404).json({ message: "Route not found." });
}

export function errorHandler(error, req, res, next) {
  const statusCode = error.statusCode || 500;
  const message = statusCode === 500 ? "Something went wrong." : error.message;

  if (statusCode === 500) {
    console.error(error);
  }

  res.status(statusCode).json({ message });
}
