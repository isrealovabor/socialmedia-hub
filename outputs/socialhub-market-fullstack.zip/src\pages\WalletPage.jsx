import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { walletApi } from "../api/client.js";
import { formatNaira } from "../data/marketData.js";

export default function WalletPage({ user, onUserRefresh }) {
  const [amount, setAmount] = useState("");
  const [method, setMethod] = useState("BANK_TRANSFER");
  const [deposits, setDeposits] = useState([]);
  const [notice, setNotice] = useState("");

  const loadDeposits = async () => {
    const data = await walletApi.deposits();
    setDeposits(data.deposits);
  };

  useEffect(() => {
    if (!user) return;
    loadDeposits().catch((error) => setNotice(error.message));
  }, [user]);

  const submitDeposit = (event) => {
    event.preventDefault();
    setNotice("");
    const numericAmount = Number(amount);
    if (!numericAmount || numericAmount < 1000) {
      setNotice("Enter an amount of at least NGN 1,000.");
      return;
    }
    walletApi
      .createDeposit({ amount: numericAmount, method, proofText: "Submitted from wallet page." })
      .then(async () => {
        setNotice("Deposit request submitted for admin review.");
        setAmount("");
        await loadDeposits();
        await onUserRefresh();
      })
      .catch((error) => setNotice(error.message));
  };

  if (!user) {
    return (
      <div>
        <div className="bg-market-dark px-3 py-2 text-sm font-bold text-white">Wallet</div>
        <section className="border-x border-b border-market-line bg-white p-4">
          <p className="text-sm text-gray-600">Login to view your wallet.</p>
          <Link className="mt-3 inline-flex h-10 items-center rounded bg-market-green px-4 text-sm font-bold text-white" to="/login">
            Login
          </Link>
        </section>
      </div>
    );
  }

  return (
    <div>
      <div className="bg-market-dark px-3 py-2 text-sm font-bold text-white">Wallet</div>
      <section className="border-x border-b border-market-line bg-white p-3">
        <p className="text-xs font-bold uppercase text-gray-500">Available balance</p>
        <p className="mt-1 text-3xl font-black text-gray-900">{formatNaira(user.walletBalance)}</p>
      </section>
      <section className="mt-3">
        <div className="bg-market-dark px-3 py-2 text-sm font-bold text-white">Deposit Funds</div>
        <form onSubmit={submitDeposit} className="space-y-3 border-x border-b border-market-line bg-white p-3">
          <label className="block">
            <span className="text-xs font-bold text-gray-600">Amount in naira</span>
            <input
              type="number"
              min="1000"
              value={amount}
              onChange={(event) => setAmount(event.target.value)}
              className="mt-1 h-11 w-full rounded border border-gray-300 px-3 outline-none focus:border-market-green"
              placeholder="10000"
            />
          </label>
          <label className="block">
            <span className="text-xs font-bold text-gray-600">Deposit method</span>
            <select
              value={method}
              onChange={(event) => setMethod(event.target.value)}
              className="mt-1 h-11 w-full rounded border border-gray-300 bg-white px-3 outline-none focus:border-market-green"
            >
              <option value="BANK_TRANSFER">Bank Transfer</option>
              <option value="BITCOIN">Bitcoin</option>
            </select>
          </label>
          <button
            type="submit"
            className="tap-highlight h-11 w-full rounded bg-market-green text-sm font-bold text-white"
          >
            Submit
          </button>
          {notice && <p className="text-sm font-semibold text-market-green">{notice}</p>}
        </form>
      </section>
      <section className="mt-3">
        <div className="bg-market-dark px-3 py-2 text-sm font-bold text-white">Deposit History</div>
        <div className="border-x border-market-line bg-white">
          {!deposits.length && (
            <div className="border-b border-market-line px-3 py-3 text-sm text-gray-600">
              No deposit requests yet.
            </div>
          )}
          {deposits.map((deposit) => (
            <div key={deposit.id} className="flex items-center justify-between border-b border-market-line px-3 py-3">
              <div>
                <p className="text-sm font-bold text-gray-900">{deposit.method.replace("_", " ")}</p>
                <p className="text-xs text-gray-500">{deposit.reference || deposit.id}</p>
              </div>
              <div className="text-right">
                <p className="text-sm font-bold text-gray-900">{formatNaira(deposit.amount)}</p>
                <p className="text-xs font-semibold text-market-green">{deposit.status}</p>
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}
