import { useState } from "react";
import { Link, useLocation } from "react-router-dom";
import { Home, LayoutDashboard, ShoppingCart, WalletCards } from "lucide-react";
import Header from "./Header.jsx";

export default function Layout({ children, cartCount, categories }) {
  const [categoryOpen, setCategoryOpen] = useState(false);
  const location = useLocation();

  const closeCategory = () => setCategoryOpen(false);

  return (
    <div className="min-h-screen bg-market-page">
      <div className="mx-auto min-h-screen max-w-[480px] bg-market-page">
        <Header
          categoryOpen={categoryOpen}
          onCategoryToggle={() => setCategoryOpen((open) => !open)}
          onCategoryClose={closeCategory}
          categories={categories}
        />
        <main onClick={closeCategory} className="pb-20">
          {children}
        </main>
        <nav className="fixed bottom-0 left-1/2 z-30 grid h-14 w-full max-w-[480px] -translate-x-1/2 grid-cols-4 border-t border-market-line bg-white text-[11px] font-semibold text-gray-600">
          <NavItem to="/" icon={Home} label="Home" active={location.pathname === "/"} />
          <NavItem
            to="/dashboard"
            icon={LayoutDashboard}
            label="Dashboard"
            active={location.pathname === "/dashboard"}
          />
          <NavItem
            to="/wallet"
            icon={WalletCards}
            label="Wallet"
            active={location.pathname === "/wallet"}
          />
          <NavItem
            to="/cart"
            icon={ShoppingCart}
            label={`Cart${cartCount ? ` (${cartCount})` : ""}`}
            active={location.pathname === "/cart"}
          />
        </nav>
      </div>
    </div>
  );
}

function NavItem({ to, icon: Icon, label, active }) {
  return (
    <Link
      to={to}
      className={`tap-highlight flex flex-col items-center justify-center gap-0.5 ${
        active ? "text-market-green" : "text-gray-600"
      }`}
    >
      <Icon size={20} />
      <span>{label}</span>
    </Link>
  );
}
