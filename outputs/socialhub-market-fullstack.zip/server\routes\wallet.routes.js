import { Router } from "express";
import { requireAuth } from "../middleware/auth.js";
import { prisma } from "../prisma.js";
import { asyncHandler } from "../utils/errors.js";
import { depositDto, publicUser } from "../utils/format.js";
import { validate } from "../utils/validation.js";
import { depositSchema } from "../validators/wallet.validators.js";

const router = Router();

router.get(
  "/wallet",
  requireAuth,
  asyncHandler(async (req, res) => {
    res.json({ user: publicUser(req.user), balance: publicUser(req.user).walletBalance });
  })
);

router.post(
  "/deposits",
  requireAuth,
  validate(depositSchema),
  asyncHandler(async (req, res) => {
    const reference = `DEP-${Date.now()}-${Math.floor(Math.random() * 10000)}`;
    const deposit = await prisma.deposit.create({
      data: {
        userId: req.user.id,
        amount: req.body.amount,
        method: req.body.method,
        proofText: req.body.proofText,
        reference,
      },
    });
    res.status(201).json({ deposit: depositDto(deposit) });
  })
);

router.get(
  "/deposits/my",
  requireAuth,
  asyncHandler(async (req, res) => {
    const deposits = await prisma.deposit.findMany({
      where: { userId: req.user.id },
      orderBy: { createdAt: "desc" },
    });
    res.json({ deposits: deposits.map(depositDto) });
  })
);

export default router;
